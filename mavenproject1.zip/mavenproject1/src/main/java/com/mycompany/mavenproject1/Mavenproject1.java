/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Mavenproject1 {

    // Stored user info
    static String storedUsername;
    static String storedPassword;
    static String storedPhone;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== Registration ===");
        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        System.out.print("Enter phone number (with international code): ");
        String phone = scanner.nextLine();

        boolean isUsernameValid = checkUserName(username);
        boolean isPasswordValid = checkPasswordComplexity(password);
        boolean isPhoneValid = checkCellPhoneNumber(phone);

        if (isUsernameValid && isPasswordValid && isPhoneValid) {
            storedUsername = username;
            storedPassword = password;
            storedPhone = phone;
            System.out.println("User registered successfully!\n");
        } else {
            System.out.println("Registration failed. Please check your inputs.\n");
        }

        System.out.println("=== Login ===");
        System.out.print("Enter username: ");
        String loginUser = scanner.nextLine();

        System.out.print("Enter password: ");
        String loginPass = scanner.nextLine();

        boolean loginSuccess = loginUser(loginUser, loginPass);
        System.out.println(returnLoginStatus(loginSuccess));
    }

    public static boolean checkUserName(String username) {
        if (username.contains("_") && username.length() <= 5) {
            System.out.println("Username successfully captured.");
            return true;
        } else {
            System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length");
            return false;
        }
    }

    public static boolean checkPasswordComplexity(String password) {
        // At least 8 chars, 1 capital letter, 1 digit, 1 special character
        String regex = "^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*]).{8,}$";
        if (password.matches(regex)) {
            System.out.println("Password successfully captured.");
            return true;
        } else {
            System.out.println("Password is not correctly formatted: please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            return false;
        }
    }

    public static boolean checkCellPhoneNumber(String phone) {
        // SA phone numbers: e.g. +27821234567 (no more than 10 digits after country code)
        String regex = "^\\+27\\d{9,10}$";
        if (phone.matches(regex)) {
            System.out.println("Cell phone number successfully added.");
            return true;
        } else {
            System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
            return false;
        }
    }

    public static boolean loginUser(String username, String password) {
        return username.equals(storedUsername) && password.equals(storedPassword);
    }

    public static String returnLoginStatus(boolean success) {
        if (success) {
            return "Welcome " + storedUsername + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}
