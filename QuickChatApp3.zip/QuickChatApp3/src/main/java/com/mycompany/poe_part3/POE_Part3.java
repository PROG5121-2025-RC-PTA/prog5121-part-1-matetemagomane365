/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchatapp;

import java.util.*;
import javax.swing.JOptionPane;
/**
 *
 * @author RC_Student_lab
 */
public class POE_Part3 {

    public static void main(String[] args) {
        System.out.println("QuickChatApp");
        
 
public class QuickChatApp {
    static String storedUsername;
    static String storedPassword;
    static String storedPhone;

    static List<Message> sentMessages = new ArrayList<>();
    static List<Message> disregardedMessages = new ArrayList<>();
    static List<Message> storedMessages = new ArrayList<>();
    static List<String> messageHashes = new ArrayList<>();
    static List<String> messageIDs = new ArrayList<>();

    static int totalMessagesSent = 0;
    static boolean isLoggedIn = false;
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Welcome to QuickChat");

        if (!isLoggedIn) {
            System.out.println("=== Registration ===");
            System.out.print("Enter username: ");
            String username = scanner.nextLine();

            System.out.print("Enter password: ");
            String password = scanner.nextLine();

            System.out.print("Enter phone number (with international code): ");
            String phone = scanner.nextLine();

            if (checkUserName(username) && checkPasswordComplexity(password) && checkCellPhoneNumber(phone)) {
                storedUsername = username;
                storedPassword = password;
                storedPhone = phone;
                isLoggedIn = true;
                System.out.println("User registered successfully!\n");
            } else {
                System.out.println("Registration failed.\n");
                return;
            }
        }

        if (isLoggedIn) {
            System.out.println("=== Login ===");
            System.out.print("Enter username: ");
            String loginUser = scanner.nextLine();
            System.out.print("Enter password: ");
            String loginPass = scanner.nextLine();

            if (!loginUser(loginUser, loginPass)) {
                System.out.println("Login failed. Exiting.");
                return;
            }
            System.out.println(returnLoginStatus(true));
        }

        messageInputFlow();

        boolean running = true;
        while (running) {
            displayMenu();
            int choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1 -> displaySendersAndRecipients();
                case 2 -> displayLongestMessage();
                case 3 -> searchMessageByID();
                case 4 -> searchMessagesByRecipient();
                case 5 -> deleteMessageByHash();
                case 6 -> displayFullReport();
                case 7 -> running = false;
                default -> System.out.println("Invalid choice.");
            }
        }
        scanner.close();
    }

    static void messageInputFlow() {
        System.out.print("Enter the number of messages you wish to send: ");
        int count = scanner.nextInt();
        scanner.nextLine();

        for (int i = 0; i < count; i++) {
            System.out.print("Recipient number: ");
            String recipient = scanner.nextLine();
            System.out.print("Message: ");
            String text = scanner.nextLine();

            if (text.length() > 50) {
                System.out.println("Message too long. Retry.");
                i--;
                continue;
            }

            totalMessagesSent++;
            Message msg = new Message(totalMessagesSent, recipient, text);
            String status = msg.sentMessage(scanner);

            switch (status) {
                case "Message successfully sent." -> {
                    sentMessages.add(msg);
                    messageHashes.add(msg.getMessageHash());
                    messageIDs.add(msg.getMessageID());
                }
                case "Message successfully stored." -> storedMessages.add(msg);
                case "Press 0 to delete message." -> disregardedMessages.add(msg);
            }

            JOptionPane.showMessageDialog(null,
                "MessageID: " + msg.getMessageID() +
                "\nHash: " + msg.getMessageHash() +
                "\nRecipient: " + msg.getRecipient() +
                "\nMessage: " + msg.getMessageText(),
                "Details", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    static void displaySendersAndRecipients() {
        for (Message msg : sentMessages) {
            System.out.println("Recipient: " + msg.getRecipient());
        }
    }

    static void displayLongestMessage() {
        Message longest = null;
        for (Message m : sentMessages) {
            if (longest == null || m.getMessageText().length() > longest.getMessageText().length()) {
                longest = m;
            }
        }
        if (longest != null) System.out.println("Longest Message: " + longest.getMessageText());
    }

    static void searchMessageByID() {
        System.out.print("Enter Message ID: ");
        String id = scanner.nextLine();
        for (Message m : sentMessages) {
            if (m.getMessageID().equals(id)) {
                System.out.println("Recipient: " + m.getRecipient() + "\nMessage: " + m.getMessageText());
                return;
            }
        }
        System.out.println("Message not found.");
    }

    static void searchMessagesByRecipient() {
        System.out.print("Enter recipient number: ");
        String rec = scanner.nextLine();
        for (Message m : sentMessages) {
            if (m.getRecipient().equals(rec)) {
                System.out.println(m.getMessageText());
            }
        }
        for (Message m : storedMessages) {
            if (m.getRecipient().equals(rec)) {
                System.out.println(m.getMessageText());
            }
        }
    }

    static void deleteMessageByHash() {
        System.out.print("Enter message hash: ");
        String hash = scanner.nextLine();
        Iterator<Message> it = sentMessages.iterator();
        while (it.hasNext()) {
            Message m = it.next();
            if (m.getMessageHash().equals(hash)) {
                it.remove();
                System.out.println("Message deleted.");
                return;
            }
        }
        System.out.println("Message hash not found.");
    }

    static void displayFullReport() {
        System.out.println("===== SENT MESSAGES REPORT =====");
        for (Message m : sentMessages) {
            System.out.println("Hash: " + m.getMessageHash());
            System.out.println("Recipient: " + m.getRecipient());
            System.out.println("Message: " + m.getMessageText());
            System.out.println("------------------------------");
        }
    }

    static void displayMenu() {
        System.out.println("\n--- Menu ---");
        System.out.println("1. Display Senders & Recipients");
        System.out.println("2. Display Longest Message");
        System.out.println("3. Search Message by ID");
        System.out.println("4. Search Messages by Recipient");
        System.out.println("5. Delete Message by Hash");
        System.out.println("6. Display Full Report");
        System.out.println("7. Exit");
        System.out.print("Choose: ");
    }

    static boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    static boolean checkPasswordComplexity(String password) {
        return password.matches("^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*]).{8,}$");
    }

    static boolean checkCellPhoneNumber(String phone) {
        return phone.matches("^\\+27\\d{9,10}$");
    }

    static boolean loginUser(String username, String password) {
        return username.equals(storedUsername) && password.equals(storedPassword);
    }

    static String returnLoginStatus(boolean success) {
        return success ? "Welcome " + storedUsername + ", good to see you again." : "Login failed.";
    }
}

class Message {
    private String messageID;
    private int messageNum;
    private String recipient;
    private String messageText;
    private String messageHash;

    public Message(int msgNum, String recipient, String messageText) {
        this.messageNum = msgNum;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageID = generateMessageID();
        this.messageHash = createMessageHash();
    }

    private String generateMessageID() {
        return String.format("%010d", new Random().nextInt(1_000_000_000));
    }

    public String createMessageHash() {
        String[] words = messageText.split(" ");
        String first = words[0].toUpperCase();
        String last = words[words.length - 1].toUpperCase();
        return String.format("%02d:%d:%s%s", Integer.parseInt(messageID.substring(0, 2)), messageNum, first, last);
    }

    public String sentMessage(Scanner scanner) {
        System.out.println("1. Send\n2. Disregard\n3. Store");
        int choice = scanner.nextInt();
        scanner.nextLine();
        return switch (choice) {
            case 1 -> "Message successfully sent.";
            case 2 -> "Press 0 to delete message.";
            case 3 -> "Message successfully stored.";
            default -> "Invalid";
        };
    }

    public String getMessageID() { return messageID; }
    public String getRecipient() { return recipient; }
    public String getMessageText() { return messageText; }
    public String getMessageHash() { return messageHash; }
}

    }
}
