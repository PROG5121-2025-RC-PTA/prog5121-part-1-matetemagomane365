/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchatapp2;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import javax.swing.JOptionPane;

class Message {
    private String messageID;
    private int numMessagesSent;
    private String recipient;
    private String messageText;
    private String messageHash;

    public Message(int numMessagesSent, String recipient, String messageText) {
        this.messageID = generateMessageID();
        this.numMessagesSent = numMessagesSent;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageHash = createMessageHash();
    }

    public String getMessageID() {
        return messageID;
    }

    public int getNumMessagesSent() {
        return numMessagesSent;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }

    public String getMessageHash() {
        return messageHash;
    }

    // Method Functionality: This method ensures that the message ID is not more than ten characters.
    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    // Method Functionality: This method ensures that the recipient cell number is no more than ten characters long and starts with.
    public boolean checkRecipientCell() {
        return recipient.length() <= 10 && recipient.startsWith("+");
    }

    // Method Functionality: This method creates and returns the Message Hash.
    public String createMessageHash() {
        if (messageText == null || messageText.isEmpty()) {
            return "INVALID_MESSAGE"; // Handle empty message case
        }
        String[] words = messageText.split("\\s+");
        String firstWord = words[0].toUpperCase();
        String lastWord = words[words.length - 1].toUpperCase();
        return String.format("%02d:%d:%s%s",
                             Integer.parseInt(messageID.substring(0, 2)),
                             numMessagesSent,
                             firstWord,
                             lastWord);
    }

    // Method Functionality: This method should allow the user to choose if they want to send, store, or disregard the message.
    public String sentMessage(Scanner scanner) {
        System.out.println("Choose an option:");
        System.out.println("1) Send Message");
        System.out.println("2) Disregard Message");
        System.out.println("3) Store Message to send later");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        switch (choice) {
            case 1:
                return "Message successfully sent.";
            case 2:
                return "Press 0 to delete message.";
            case 3:
                return "Message successfully stored.";
            default:
                return "Invalid choice.";
        }
    }

    // Method Functionality: This method returns a list of all the messages sent while the program is running.
    // We'll manage the list of sent messages in the main application class. This method will likely not be needed within the Message class itself.

    // Method Functionality: This method returns the total number of messages sent.
    // This will also be managed in the main application class.

    // Your own defined storeMessage() method
    public void storeMessage() {
        // We'll implement the JSON storage later using ChatGPT's help.
        System.out.println("Message storage functionality will be implemented later.");
    }

    private String generateMessageID() {
        Random random = new Random();
        return String.format("%010d", random.nextInt(1000000000));
    }
}

public class QuickChatApp2 {
    private static List<Message> sentMessages = new ArrayList<>();
    private static int totalMessagesSent = 0;
    private static boolean isLoggedIn = true; // For now, we'll assume the user is logged in
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Welcome to QuickChat");

        if (!isLoggedIn) {
            System.out.println("Please log in to send messages.");
            // In a real application, you'd have a login mechanism here
            return;
        }

        System.out.print("Enter the number of messages you wish to enter: ");
        int numMessagesToEnter = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        for (int i = 0; i < numMessagesToEnter; i++) {
            totalMessagesSent++;
            System.out.println("\nEnter details for Message " + totalMessagesSent + ":");

            System.out.print("Recipient's cell number (e.g., +27xxxxxxxxx): ");
            String recipient = scanner.nextLine();

            System.out.print("Enter your message (max 250 characters): ");
            String messageText = scanner.nextLine();

            if (messageText.length() > 50) { // Changed to 50 as per the error message
                System.out.println("Please enter a message of less than 50 characters.");
                totalMessagesSent--; // Decrement as this message wasn't successfully created
                i--; // Re-do this iteration
                continue;
            }

            Message message = new Message(totalMessagesSent, recipient, messageText);

            System.out.println("Message Hash: " + message.getMessageHash());

            String sendMessageResult = message.sentMessage(scanner);
            System.out.println(sendMessageResult);

            if (sendMessageResult.equals("Message successfully sent.")) {
                sentMessages.add(message);
                JOptionPane.showMessageDialog(null,
                        "MessageID: " + message.getMessageID() + "\n" +
                        "Message Hash: " + message.getMessageHash() + "\n" +
                        "Recipient: " + message.getRecipient() + "\n" +
                        "Message: " + message.getMessageText(),
                        "Message Details", JOptionPane.INFORMATION_MESSAGE);
            } else if (sendMessageResult.equals("Message successfully stored.")) {
                message.storeMessage(); // Call the store message functionality
            }
        }

        boolean running = true;
        while (running) {
            displayMenu();
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    System.out.println("Sending messages...");
                    // The message sending logic is already handled above
                    break;
                case 2:
                    System.out.println("Coming Soon");
                    break;
                case 3:
                    System.out.println("Exiting QuickChat. Total messages sent: " + totalMessagesSent);
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }

    private static void displayMenu() {
        System.out.println("\nChoose an option:");
        System.out.println("1) Send Messages");
        System.out.println("2) Show recently sent messages");
        System.out.println("3) Quit");
        System.out.print("Enter your choice: ");
    }
}

